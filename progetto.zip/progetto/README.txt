per compilare: 

arrivare alla cartella source code da riga di comando ed eseguire :

qmake progetto_v2.pro
make
./progetto_v2

Al momento della stesura di questo file il codice compila ed esegue senza problemi sulla macchina virtuale fornita sul moodle. 



Di seguito delle considerazioni personali lasciate fuori dalla relazione e non utili alla valutazione: 
Potrei avere implementato più funzionalità e aver fatto meglio alcune parti, ma avendo superato di gran lunga il monte ore
consigliato all'interno del documento di specifiche ho deciso di non continuare anche perché ho bisogno di dedicarmi ad altri corsi. 



