#include "datapair.h"

//COSTRUTTORI_____________________________________________________________________
template<typename T>
dataPair<T>::dataPair() : valore(-999), giorno(-999), mese(-999), anno(-999) {};
template<typename T>
dataPair<T>::dataPair(T v, int g,int m,int a) : valore(v), giorno(g), mese(m), anno(a) {};
template<typename T>
dataPair<T>::dataPair(const dataPair<T>& odp) {
    valore=odp.valore;
    giorno=odp.giorno;
    mese=odp.mese;
    anno=odp.anno;
};
//________________________________________________________________________________



//GETTER_____________________________________________________________________
template<typename T>
T dataPair<T>::getValore() const {return valore;};
template<typename T>
int dataPair<T>::getGiorno() const {return giorno;};
template<typename T>
int dataPair<T>::getMese() const {return mese;};
template<typename T>
int dataPair<T>::getAnno() const {return anno;};
//________________________________________________________________________________



//SETTER//________________________________________________________________________
template<typename T>
void dataPair<T>::setValore(T v) {valore=v;};
template<typename T>
void dataPair<T>::setGiorno(int g){giorno=g;};
template<typename T>
void dataPair<T>::setMese(int m){mese=m;};
template<typename T>
void dataPair<T>::setAnno(int a){anno=a;};
template<typename T>
void dataPair<T>::setData(int g,int m,int a) {
    giorno=g;
    mese=m;
    anno=a;
};
//________________________________________________________________________________
