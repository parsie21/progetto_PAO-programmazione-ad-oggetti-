#include "mainwindow.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    //imposto la icona dell'app
    QIcon icon(":/icone_GUI/icona_app_chart.png");
    a.setWindowIcon(icon);
    a.setApplicationName("SensLab");



    MainWindow w;
    w.show();
    return a.exec();
}
