/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.2.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout_5;
    QFrame *frame_5;
    QHBoxLayout *horizontalLayout_4;
    QFrame *frame_lista;
    QVBoxLayout *verticalLayout_7;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label;
    QPushButton *pushButton_Refresh;
    QListWidget *listWidget;
    QLabel *label_3;
    QLabel *label_Sensore_selezionato_value;
    QPushButton *pushButton_Show_Chart;
    QPushButton *pushButton_Show_Values;
    QPushButton *pushButton_Delete;
    QSpacerItem *verticalSpacer;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_8;
    QPushButton *pushButton_Search;
    QLineEdit *lineEdit;
    QPushButton *pushButton_Add;
    QFrame *frame_Valori;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_2;
    QPlainTextEdit *plainTextEdit;
    QPushButton *pushButton_Save;
    QPushButton *pushButton_Clear;
    QFrame *frame_3;
    QVBoxLayout *verticalLayout_9;
    QFrame *frame_chart;
    QHBoxLayout *horizontalLayout_6;
    QSplitter *splitter;
    QFrame *frame_4;
    QHBoxLayout *horizontalLayout_3;
    QFrame *frame_7;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_Min;
    QLabel *label_Avg;
    QLabel *label_Max;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_Min_Value;
    QLabel *label_Avg_Value;
    QLabel *label_Max_Value;
    QSpacerItem *horizontalSpacer;
    QFrame *frame_2;
    QHBoxLayout *horizontalLayout_2;
    QVBoxLayout *verticalLayout_5;
    QLabel *label_14;
    QLabel *label_13;
    QLabel *label_11;
    QVBoxLayout *verticalLayout_6;
    QLabel *label_tipo_value;
    QLabel *label_nome_value;
    QLabel *label_n_valori;
    QLabel *label_12;
    QLabel *label_Descrizione_Value;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1234, 707);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        horizontalLayout_5 = new QHBoxLayout(centralwidget);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        frame_5 = new QFrame(centralwidget);
        frame_5->setObjectName(QString::fromUtf8("frame_5"));
        frame_5->setFrameShape(QFrame::StyledPanel);
        frame_5->setFrameShadow(QFrame::Raised);
        horizontalLayout_4 = new QHBoxLayout(frame_5);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        frame_lista = new QFrame(frame_5);
        frame_lista->setObjectName(QString::fromUtf8("frame_lista"));
        frame_lista->setFrameShape(QFrame::StyledPanel);
        frame_lista->setFrameShadow(QFrame::Raised);
        verticalLayout_7 = new QVBoxLayout(frame_lista);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        label = new QLabel(frame_lista);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout_7->addWidget(label);

        pushButton_Refresh = new QPushButton(frame_lista);
        pushButton_Refresh->setObjectName(QString::fromUtf8("pushButton_Refresh"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icone_GUI/icons8-refresh-48.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_Refresh->setIcon(icon);

        horizontalLayout_7->addWidget(pushButton_Refresh);


        verticalLayout_7->addLayout(horizontalLayout_7);

        listWidget = new QListWidget(frame_lista);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));

        verticalLayout_7->addWidget(listWidget);

        label_3 = new QLabel(frame_lista);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout_7->addWidget(label_3);

        label_Sensore_selezionato_value = new QLabel(frame_lista);
        label_Sensore_selezionato_value->setObjectName(QString::fromUtf8("label_Sensore_selezionato_value"));

        verticalLayout_7->addWidget(label_Sensore_selezionato_value);

        pushButton_Show_Chart = new QPushButton(frame_lista);
        pushButton_Show_Chart->setObjectName(QString::fromUtf8("pushButton_Show_Chart"));

        verticalLayout_7->addWidget(pushButton_Show_Chart);

        pushButton_Show_Values = new QPushButton(frame_lista);
        pushButton_Show_Values->setObjectName(QString::fromUtf8("pushButton_Show_Values"));

        verticalLayout_7->addWidget(pushButton_Show_Values);

        pushButton_Delete = new QPushButton(frame_lista);
        pushButton_Delete->setObjectName(QString::fromUtf8("pushButton_Delete"));

        verticalLayout_7->addWidget(pushButton_Delete);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_7->addItem(verticalSpacer);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        pushButton_Search = new QPushButton(frame_lista);
        pushButton_Search->setObjectName(QString::fromUtf8("pushButton_Search"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/icone_GUI/search.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_Search->setIcon(icon1);

        horizontalLayout_8->addWidget(pushButton_Search);

        lineEdit = new QLineEdit(frame_lista);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));

        horizontalLayout_8->addWidget(lineEdit);

        horizontalLayout_8->setStretch(0, 1);
        horizontalLayout_8->setStretch(1, 6);

        verticalLayout->addLayout(horizontalLayout_8);

        pushButton_Add = new QPushButton(frame_lista);
        pushButton_Add->setObjectName(QString::fromUtf8("pushButton_Add"));

        verticalLayout->addWidget(pushButton_Add);


        verticalLayout_7->addLayout(verticalLayout);

        verticalLayout_7->setStretch(1, 1);

        horizontalLayout_4->addWidget(frame_lista);

        frame_Valori = new QFrame(frame_5);
        frame_Valori->setObjectName(QString::fromUtf8("frame_Valori"));
        frame_Valori->setFrameShape(QFrame::StyledPanel);
        frame_Valori->setFrameShadow(QFrame::Raised);
        verticalLayout_2 = new QVBoxLayout(frame_Valori);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label_2 = new QLabel(frame_Valori);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout_2->addWidget(label_2);

        plainTextEdit = new QPlainTextEdit(frame_Valori);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));

        verticalLayout_2->addWidget(plainTextEdit);

        pushButton_Save = new QPushButton(frame_Valori);
        pushButton_Save->setObjectName(QString::fromUtf8("pushButton_Save"));

        verticalLayout_2->addWidget(pushButton_Save);

        pushButton_Clear = new QPushButton(frame_Valori);
        pushButton_Clear->setObjectName(QString::fromUtf8("pushButton_Clear"));

        verticalLayout_2->addWidget(pushButton_Clear);


        horizontalLayout_4->addWidget(frame_Valori);

        frame_3 = new QFrame(frame_5);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        verticalLayout_9 = new QVBoxLayout(frame_3);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        frame_chart = new QFrame(frame_3);
        frame_chart->setObjectName(QString::fromUtf8("frame_chart"));
        frame_chart->setFrameShape(QFrame::StyledPanel);
        frame_chart->setFrameShadow(QFrame::Raised);
        horizontalLayout_6 = new QHBoxLayout(frame_chart);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));

        verticalLayout_9->addWidget(frame_chart);

        splitter = new QSplitter(frame_3);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Vertical);
        frame_4 = new QFrame(splitter);
        frame_4->setObjectName(QString::fromUtf8("frame_4"));
        frame_4->setFrameShape(QFrame::StyledPanel);
        frame_4->setFrameShadow(QFrame::Raised);
        horizontalLayout_3 = new QHBoxLayout(frame_4);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        frame_7 = new QFrame(frame_4);
        frame_7->setObjectName(QString::fromUtf8("frame_7"));
        frame_7->setFrameShape(QFrame::StyledPanel);
        frame_7->setFrameShadow(QFrame::Raised);
        horizontalLayout = new QHBoxLayout(frame_7);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label_Min = new QLabel(frame_7);
        label_Min->setObjectName(QString::fromUtf8("label_Min"));

        verticalLayout_3->addWidget(label_Min);

        label_Avg = new QLabel(frame_7);
        label_Avg->setObjectName(QString::fromUtf8("label_Avg"));

        verticalLayout_3->addWidget(label_Avg);

        label_Max = new QLabel(frame_7);
        label_Max->setObjectName(QString::fromUtf8("label_Max"));

        verticalLayout_3->addWidget(label_Max);


        horizontalLayout->addLayout(verticalLayout_3);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        label_Min_Value = new QLabel(frame_7);
        label_Min_Value->setObjectName(QString::fromUtf8("label_Min_Value"));

        verticalLayout_4->addWidget(label_Min_Value);

        label_Avg_Value = new QLabel(frame_7);
        label_Avg_Value->setObjectName(QString::fromUtf8("label_Avg_Value"));

        verticalLayout_4->addWidget(label_Avg_Value);

        label_Max_Value = new QLabel(frame_7);
        label_Max_Value->setObjectName(QString::fromUtf8("label_Max_Value"));

        verticalLayout_4->addWidget(label_Max_Value);


        horizontalLayout->addLayout(verticalLayout_4);


        horizontalLayout_3->addWidget(frame_7);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer);

        frame_2 = new QFrame(frame_4);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        horizontalLayout_2 = new QHBoxLayout(frame_2);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        label_14 = new QLabel(frame_2);
        label_14->setObjectName(QString::fromUtf8("label_14"));

        verticalLayout_5->addWidget(label_14);

        label_13 = new QLabel(frame_2);
        label_13->setObjectName(QString::fromUtf8("label_13"));

        verticalLayout_5->addWidget(label_13);

        label_11 = new QLabel(frame_2);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        verticalLayout_5->addWidget(label_11);


        horizontalLayout_2->addLayout(verticalLayout_5);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        label_tipo_value = new QLabel(frame_2);
        label_tipo_value->setObjectName(QString::fromUtf8("label_tipo_value"));

        verticalLayout_6->addWidget(label_tipo_value);

        label_nome_value = new QLabel(frame_2);
        label_nome_value->setObjectName(QString::fromUtf8("label_nome_value"));

        verticalLayout_6->addWidget(label_nome_value);

        label_n_valori = new QLabel(frame_2);
        label_n_valori->setObjectName(QString::fromUtf8("label_n_valori"));

        verticalLayout_6->addWidget(label_n_valori);


        horizontalLayout_2->addLayout(verticalLayout_6);

        horizontalLayout_2->setStretch(0, 1);
        horizontalLayout_2->setStretch(1, 6);

        horizontalLayout_3->addWidget(frame_2);

        splitter->addWidget(frame_4);

        verticalLayout_9->addWidget(splitter);

        label_12 = new QLabel(frame_3);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        verticalLayout_9->addWidget(label_12);

        label_Descrizione_Value = new QLabel(frame_3);
        label_Descrizione_Value->setObjectName(QString::fromUtf8("label_Descrizione_Value"));
        label_Descrizione_Value->setMaximumSize(QSize(1080, 1080));

        verticalLayout_9->addWidget(label_Descrizione_Value);

        verticalLayout_9->setStretch(0, 6);
        verticalLayout_9->setStretch(1, 1);
        verticalLayout_9->setStretch(2, 1);

        horizontalLayout_4->addWidget(frame_3);

        horizontalLayout_4->setStretch(0, 1);
        horizontalLayout_4->setStretch(1, 1);
        horizontalLayout_4->setStretch(2, 4);

        horizontalLayout_5->addWidget(frame_5);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1234, 25));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "Seleziona un sensore", nullptr));
        pushButton_Refresh->setText(QString());
        label_3->setText(QCoreApplication::translate("MainWindow", "Sensore selezionato: ", nullptr));
        label_Sensore_selezionato_value->setText(QString());
        pushButton_Show_Chart->setText(QCoreApplication::translate("MainWindow", "Show Chart", nullptr));
        pushButton_Show_Values->setText(QCoreApplication::translate("MainWindow", "Show Values", nullptr));
        pushButton_Delete->setText(QCoreApplication::translate("MainWindow", "Delete", nullptr));
        pushButton_Search->setText(QString());
        pushButton_Add->setText(QCoreApplication::translate("MainWindow", "Add", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Valori", nullptr));
        pushButton_Save->setText(QCoreApplication::translate("MainWindow", "Save", nullptr));
        pushButton_Clear->setText(QCoreApplication::translate("MainWindow", "Clear", nullptr));
        label_Min->setText(QCoreApplication::translate("MainWindow", "Min", nullptr));
        label_Avg->setText(QCoreApplication::translate("MainWindow", "Avg", nullptr));
        label_Max->setText(QCoreApplication::translate("MainWindow", "Max", nullptr));
        label_Min_Value->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        label_Avg_Value->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        label_Max_Value->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        label_14->setText(QCoreApplication::translate("MainWindow", "Tipo", nullptr));
        label_13->setText(QCoreApplication::translate("MainWindow", "Nome ", nullptr));
        label_11->setText(QCoreApplication::translate("MainWindow", "n valori", nullptr));
        label_tipo_value->setText(QCoreApplication::translate("MainWindow", "__", nullptr));
        label_nome_value->setText(QCoreApplication::translate("MainWindow", "__", nullptr));
        label_n_valori->setText(QCoreApplication::translate("MainWindow", "__", nullptr));
        label_12->setText(QCoreApplication::translate("MainWindow", "Descrizione", nullptr));
        label_Descrizione_Value->setText(QCoreApplication::translate("MainWindow", "__", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
