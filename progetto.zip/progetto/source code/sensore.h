#ifndef SENSORE_H
#define SENSORE_H
#include "datapair.h"
#include <vector>
#include <QString>
using std::vector;


/*SENSORE______________________________________________________________*/
class sensore {
private:
    QString nome_sensore;
public:
    QString descrizione;
    //COSTRUTTORE
    sensore();
    sensore(QString);
    sensore(QString, QString);
    sensore(const sensore&);
    //METODI SET E GET
    QString getNomeSensore() const;
    void setNomeSensore(QString);
    //POLIMORFISMO E ASTRAZIONE DELLA CLASSE
    virtual QString getNomeTipoSensore() const = 0;
    virtual ~sensore() = default;

    virtual int getMin() const = 0;
    virtual int getMax() const = 0;
    virtual int getAvg() const = 0;
};
/*_____________________________________________________________________*/







/*SENSORE QUALITA ARIA_________________________________________________*/
class sensoreAria : public sensore {
private:
    const QString nome_tipo_sensore = "Aria";
    vector<dataPair<int>> vec;
public:
    sensoreAria();
    sensoreAria(QString, QString);
    sensoreAria(const sensoreAria&);
    virtual QString getNomeTipoSensore() const;

    vector<dataPair<int>> getDati() const;
    void setDati(const vector<dataPair<int>>&);

    virtual int getMin() const ;
    virtual int getMax() const ;
    virtual int getAvg() const ;
};
/*_____________________________________________________________________*/






/*SENSORE TEMPERATURA__________________________________________________*/
class sensoreTemperatura : public sensore {
private:
    const QString nome_tipo_sensore = "Temperatura";
    vector<dataPair<double>> vec;
public:
    sensoreTemperatura();
    sensoreTemperatura(QString, QString);
    sensoreTemperatura(const sensoreTemperatura&);
    virtual QString getNomeTipoSensore() const;

    vector<dataPair<double>> getDati() const;
    void setDati(const vector<dataPair<double>>&);

    virtual int getMin() const ;
    virtual int getMax() const ;
    virtual int getAvg() const ;
};
/*_____________________________________________________________________*/






/*SENSORE UMIDITA______________________________________________________*/
class sensoreUmidita : public sensore {
private:
    const QString nome_tipo_sensore = "Umidita";
    vector<dataPair<int>> vec;
public:
    sensoreUmidita();
    sensoreUmidita(QString, QString);
    sensoreUmidita(const sensoreUmidita&);
    virtual QString getNomeTipoSensore() const;

    vector<dataPair<int>> getDati() const;
    void setDati(const vector<dataPair<int>>&);

    virtual int getMin() const ;
    virtual int getMax() const ;
    virtual int getAvg() const ;

};
/*_____________________________________________________________________*/
#endif // SENSORE_H
