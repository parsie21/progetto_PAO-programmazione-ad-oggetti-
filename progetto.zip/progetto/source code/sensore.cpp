#include "sensore.h"



/*SENSORE               ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


/*COSTRUTTORI SENSORE_________________________________________________*/
sensore::sensore() : nome_sensore("untitled"), descrizione("") {};
sensore::sensore(QString nome) : nome_sensore(nome){};
sensore::sensore(QString nome, QString descr) : nome_sensore(nome), descrizione(descr) {};
sensore::sensore(const sensore& s) {
    nome_sensore=s.nome_sensore;
    descrizione=s.descrizione;
};
/*_____________________________________________________________________*/
/*GETTER SENSORE_______________________________________________________*/
QString sensore::getNomeSensore() const {return nome_sensore;};
/*_____________________________________________________________________*/
/*SETTER SENSORE_______________________________________________________*/
void sensore::setNomeSensore(QString nome) {nome_sensore=nome;};
/*_____________________________________________________________________*/








/*SENSORE ARIA          ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


/*COSTRUTTORI SENSORE_ARIA ____________________________________________*/
sensoreAria::sensoreAria() : sensore(), vec() {};
sensoreAria::sensoreAria(QString nome, QString descr) : sensore(nome, descr), vec() {};
sensoreAria::sensoreAria(const sensoreAria& sA) : sensore(sA), vec(sA.vec) {};
/*_____________________________________________________________________*/
/*METODI SENSORE ARIA___________________________________________________*/
QString sensoreAria::getNomeTipoSensore() const {return nome_tipo_sensore;};
vector<dataPair<int>> sensoreAria::getDati() const {return vec;};
void sensoreAria::setDati(const vector<dataPair<int>>& nuovo) {vec=nuovo;};
/*_____________________________________________________________________*/
/*_____________________________________________________________________*/
//min, max e avg

int sensoreAria::getMax() const {
    int max = vec.begin()->getValore();
    for(auto it=vec.begin(); it!=vec.end(); it++) {
        if(max < it->getValore()) {
            max = it->getValore();
        }
    }
    return max;
};
int sensoreAria::getAvg() const {
    int length = vec.size();
    int sum=0;
    for(auto it=vec.begin(); it!=vec.end(); it++) {
        sum += it->getValore();
    }
    int avg = sum/length;
    return avg;
};
int sensoreAria::getMin() const {
    int min = vec.begin()->getValore();
    for(auto it=vec.begin(); it!=vec.end(); it++) {
        if(min > it->getValore()) {
            min = it->getValore();
        }
    }
    return min;
};

/*_____________________________________________________________________*/





/*SENSORE TEMPERATURA   ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

/*COSTRUTTORI__________________________________________________________*/
sensoreTemperatura::sensoreTemperatura() : sensore(), vec() {};
sensoreTemperatura::sensoreTemperatura(QString nome, QString descr) : sensore(nome, descr), vec() {};
sensoreTemperatura::sensoreTemperatura(const sensoreTemperatura& sT) : sensore(sT), vec(sT.vec) {};
/*_____________________________________________________________________*/

/*METODI SENSORE TEMPERATURA___________________________________________*/
QString sensoreTemperatura::getNomeTipoSensore() const {return nome_tipo_sensore;};
vector<dataPair<double>> sensoreTemperatura::getDati() const {return vec;};
void sensoreTemperatura::setDati(const vector<dataPair<double>>& nuovo) {vec=nuovo;};
/*_____________________________________________________________________*/

/*_____________________________________________________________________*/
//min, max e avg

int sensoreTemperatura::getMax() const {
    int max = vec.begin()->getValore();
    for(auto it=vec.begin(); it!=vec.end(); it++) {
        if(max < it->getValore()) {
            max = it->getValore();
        }
    }
    return max;
};
int sensoreTemperatura::getAvg() const {
    int length = vec.size();
    int sum=0;
    for(auto it=vec.begin(); it!=vec.end(); it++) {
        sum += it->getValore();
    }
    int avg = sum/length;
    return avg;
};
int sensoreTemperatura::getMin() const {
    int min = vec.begin()->getValore();
    for(auto it=vec.begin(); it!=vec.end(); it++) {
        if(min > it->getValore()) {
            min = it->getValore();
        }
    }
    return min;
};

/*_____________________________________________________________________*/





/*SENSORE UMIDITA       ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

/*COSTRUTTORI__________________________________________________________*/
sensoreUmidita::sensoreUmidita() : sensore(), vec() {};
sensoreUmidita::sensoreUmidita(QString nome, QString descr) : sensore(nome, descr), vec() {};
sensoreUmidita::sensoreUmidita(const sensoreUmidita& sU) : sensore(sU), vec(sU.vec) {};
/*_____________________________________________________________________*/


/*METODI SENSORE UMIDITA     __________________________________________*/
QString sensoreUmidita::getNomeTipoSensore() const {return nome_tipo_sensore;};
vector<dataPair<int>> sensoreUmidita::getDati() const {return vec;};
void sensoreUmidita::setDati(const vector<dataPair<int>>& nuovo) {vec=nuovo;};
/*_____________________________________________________________________*/

int sensoreUmidita::getMax() const {
    int max = vec.begin()->getValore();
    for(auto it=vec.begin(); it!=vec.end(); it++) {
        if(max < it->getValore()) {
            max = it->getValore();
        }
    }
    return max;
};
int sensoreUmidita::getAvg() const {
    int length = vec.size();
    int sum=0;
    for(auto it=vec.begin(); it!=vec.end(); it++) {
        sum += it->getValore();
    }
    int avg = sum/length;
    return avg;
};
int sensoreUmidita::getMin() const {
    int min = vec.begin()->getValore();
    for(auto it=vec.begin(); it!=vec.end(); it++) {
        if(min > it->getValore()) {
            min = it->getValore();
        }
    }
    return min;
};



