#ifndef DATAPAIR_H
#define DATAPAIR_H
template<typename T>
class dataPair {
private:
    T valore;
    int giorno;
    int mese;
    int anno;
public:
    //COSTRUTTORI
    dataPair();
    dataPair(T, int,int,int);
    dataPair(const dataPair&);
    //METODI GETTER
    T getValore() const;
    int getGiorno() const;
    int getMese() const;
    int getAnno() const;
    //METODI SETTER
    void setValore(T);
    void setGiorno(int);
    void setMese(int);
    void setAnno(int);
    void setData(int,int,int);

};

template class dataPair<int>;
template class dataPair<double>;
#endif // DATAPAIR_H
