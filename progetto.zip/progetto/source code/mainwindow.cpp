#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QStringList>
#include <QTextStream>
#include <QMessageBox>

#include "datapair.h"
#include "sensore.h"

#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QJsonParseError>
#include <QByteArray>

#include <QTime>
#include <QDate>
#include <QDateTime>
#include <QDateTimeAxis>
#include <QValueAxis>
#include <QChart>
#include <QLineSeries>
#include <QChartView>
#include <QValueAxis>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);
    setWindowTitle("SensLab");
    /*LIST WIDGET SETUP________________________*/
    filepath = QDir::currentPath();
    qDebug() << "Current path is : " + filepath ;
    /*-------------------------------------------------------------------------*/qDebug() << ""; qDebug() << ""; qDebug() << "";
    QDir dir(json_dir);
    QStringList entries = dir.entryList();
    QStringList files;

    for(const QString& el : entries) {
        QFile file(el);
        QFileInfo info(file);
        if(!info.isDir()) {
            files.append(el);
        }
        file.close();
        file.flush();
    }
    qDebug() << "File inside the json directory : ";
    for(const QString& el : files) {
        qDebug() << el;
    }
    /*-------------------------------------------------------------------------*/qDebug() << ""; qDebug() << ""; qDebug() << "";

    //adesso ho tutti i file json e il loro percorso. Iniziamo a creare per ogni file json il relativo oggetto sensore e aggiungiamolo al vector<sensori*> sensoriBox

    /*loading file datas inside the vector sensoriBox*/
    for(const QString& el : files) {
        QString json_file_path = json_dir+ "/" + el;
        QFile file(json_file_path);
        qDebug() << "working with :     " << json_file_path;
        QString file_content;
        if(file.open(QIODevice::ReadOnly)) {
            file_content = file.readAll();
            file.close();
            file.flush();
        }
        QJsonParseError error;
        QJsonDocument doc = QJsonDocument::fromJson(file_content.toUtf8(), &error);
        if(error.error!=QJsonParseError::NoError){
            qWarning() << "File not Parsed " << error.errorString();
            continue;
        }
        QJsonObject sensore = doc.object();
        QString nome_sensore = sensore["nome_sensore"].toString();
        QString descrizione = sensore["descrizione"].toString();
        QString tipo_sensore = sensore["tipo"].toString();
        QJsonArray dati = sensore["dati"].toArray();

        qDebug() << nome_sensore << " " << tipo_sensore << " " << descrizione;

        if(tipo_sensore=="aria") {
            sensoreAria* sa = new sensoreAria(nome_sensore, descrizione);
            vector<dataPair<int>> vec;
            for(auto it=dati.begin(); it!=dati.end(); it++) {
                QJsonObject obj = it->toObject();
                int valore = obj["valore"].toInt();
                int giorno = obj["giorno"].toInt();
                int mese = obj["mese"].toInt();
                int anno = obj["anno"].toInt();
                dataPair<int> dp(valore,giorno,mese,anno);
                vec.push_back(dp);
            }
            sa->setDati(vec);
            sensoriBox.push_back(sa);
            qDebug() << "Finished loading sensoreAria";
        }
        if(tipo_sensore=="temperatura") {
            sensoreTemperatura* st = new sensoreTemperatura(nome_sensore, descrizione);
            vector<dataPair<double>> vec;
            for(auto it=dati.begin(); it!=dati.end(); it++) {
                QJsonObject obj = it->toObject();
                double valore = obj["valore"].toInt();
                int giorno = obj["giorno"].toInt();
                int mese = obj["mese"].toInt();
                int anno = obj["anno"].toInt();
                dataPair<double> dp(valore,giorno,mese,anno);
                vec.push_back(dp);
            }
            st->setDati(vec);
            sensoriBox.push_back(st);
            qDebug() << "Finished loading sensoreTemperatura";


        }
        if(tipo_sensore=="umidita") {
            sensoreUmidita* su = new sensoreUmidita(nome_sensore, descrizione);
            vector<dataPair<int>> vec;
            for(auto it=dati.begin(); it!=dati.end(); it++) {
                QJsonObject obj = it->toObject();
                int valore = obj["valore"].toInt();
                int giorno = obj["giorno"].toInt();
                int mese = obj["mese"].toInt();
                int anno = obj["anno"].toInt();
                dataPair<int> dp(valore,giorno,mese,anno);
                vec.push_back(dp);
            }
            su->setDati(vec);
            sensoriBox.push_back(su);
            qDebug() << "Finished loading sensoreUmidita";
        }

    }

    /*-------------------------------------------------------------------------*/qDebug() << ""; qDebug() << ""; qDebug() << "";


    for(auto it = sensoriBox.begin(); it!=sensoriBox.end(); it++) {
        sensore* s = *it;
        QString nome = s->getNomeSensore();

        QListWidgetItem* item;

        if(typeid(*s)== typeid(sensoreAria)) {
            item = new QListWidgetItem(QIcon(":/icone_GUI/qualita_aria.png"), nome);
            ui->listWidget->addItem(item);
        }
        if(typeid(*s) == typeid(sensoreTemperatura)) {
            item = new QListWidgetItem(QIcon(":/icone_GUI/temperatura.png"), nome);
            ui->listWidget->addItem(item);
        }
        if(typeid(*s) == typeid(sensoreUmidita)) {
            item = new QListWidgetItem(QIcon(":/icone_GUI/umidita.png"), nome);
            ui->listWidget->addItem(item);
        }

    }










    /*-------------------------------------------------------------------------*/qDebug() << ""; qDebug() << ""; qDebug() << "";
    qDebug() << "ui loaded";
}




MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::on_listWidget_itemClicked(QListWidgetItem *item)
{
    QString nome = item->text();
    ui->label_Sensore_selezionato_value->setText(nome);


    //INSERISCO IL PATH ALL'INTERNO DELLA VARIABILE FILEPATH DICHIARATA IN MAINWINDOW.H
    QDir dir(json_dir);
    QStringList entries = dir.entryList();
    QStringList files;
    for(const QString& el : entries) {
        QFile file(json_dir + "/" + el);
        QFileInfo info(file);
        if(!info.isDir()){
            files.append(json_dir + "/" + el);
        }
        file.close();
    }

    for(const QString& el : files) {
        QFile file(el);
        if(file.open(QIODevice::ReadOnly)) {
            QJsonParseError error;
            QJsonDocument doc = QJsonDocument::fromJson(file.readAll(), &error);
            if(error.error!=QJsonParseError::NoError) {
                qDebug() << "Failed to parse";
                continue;
            }
            QJsonObject obj = doc.object();
            QString nome_sensore = obj["nome_sensore"].toString();
            if(nome==nome_sensore) {
                filepath = el;
                qDebug() << "Filepath: " + filepath;
            }
        }
        file.close();
    }
}

void MainWindow::on_pushButton_Show_Values_clicked()
{
    ui->plainTextEdit->clear();
    QString sensore_selezionato = ui->label_Sensore_selezionato_value->text();
    if(sensore_selezionato=="") {
        qDebug() << "Nessun sensore selezionato";
        QMessageBox::information(this,"error", "Seleziona un sensore prima");
        return;
    }
        qDebug() << "Sensore selezionato" + sensore_selezionato;


        QDir dir(json_dir);
        QStringList entries = dir.entryList();
        for(const QString& el : entries) {
            qDebug() << el;
        }
        QStringList files;
        for(const QString& el : entries) {
            QFile file(el);
            QFileInfo info(file);
            if(!info.isDir()){
                files.append(el);
            }
        }

        for(const QString& el : files) {
            qDebug() << el;
        }
        for(const QString& el : files) {
            qDebug() << "Working with " + el;
            QFile file(json_dir + "/" + el);
            if(file.open(QIODevice::ReadOnly)){
                QByteArray fileData = file.readAll(); // Leggi il contenuto del file una volta
                QJsonParseError error;
                QJsonDocument doc = QJsonDocument::fromJson(fileData, &error); // Utilizza il contenuto letto
                if(error.error != QJsonParseError::NoError) {
                    qWarning() << "Failed to Parse json file";
                } else {
                    QJsonObject obj = doc.object();
                    QString nome_sensore = obj["nome_sensore"].toString();
                    if(nome_sensore == sensore_selezionato) {
                        ui->plainTextEdit->setPlainText(QString(fileData)); // Imposta il contenuto su plainTextEdit
                    }
                }
            }
        }

}

void MainWindow::on_pushButton_Clear_clicked()
{
    ui->plainTextEdit->clear();
}

void MainWindow::on_pushButton_Search_clicked()
{
    QMessageBox::information(this, "Info", "Dal file selezionato assicurati che il nome del sensore sia univoco/diverso da quello degli altri sensori");
    ui->lineEdit->setText("");
    QString source_path = QFileDialog::getOpenFileName(nullptr, "Seleziona un file", QDir::homePath());
    qDebug() << "source path selected : " + source_path;
    ui->lineEdit->setText(source_path);
}

void MainWindow::on_pushButton_Add_clicked()
{
    QString source_file_path(ui->lineEdit->text());
    qDebug() << "source file path : " + source_file_path;


    QString json_directory_path = json_dir;
    qDebug() << "json directory path: " + json_directory_path;

    QFile oldFile(source_file_path);
    QFileInfo oldFileInfo(oldFile);
    QString oldFileContent;
    QString file_name(oldFileInfo.fileName());
    if(oldFile.open(QIODevice::ReadOnly)) {
        oldFileContent = oldFile.readAll();
        oldFile.close();
        oldFile.flush();
    }
    QFile newFile(json_directory_path + "/" + file_name);
    if(newFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream out(&newFile);
        out << oldFileContent;
    }
    newFile.close();
    newFile.flush();

    //-------------------------------------------------INZIO CODICE SETUP DELLA LISTA----------------------------------------------
    ui->listWidget->clear();
    sensoriBox.clear();
    /*LIST WIDGET SETUP (identico a quello nel setup iniziale della mainwindow________________________*/
    filepath = QDir::currentPath();
    qDebug() << "Current path is : " + filepath ;
    /*-------------------------------------------------------------------------*/qDebug() << ""; qDebug() << ""; qDebug() << "";
    QDir dir(json_dir);
    QStringList entries = dir.entryList();
    QStringList files;

    for(const QString& el : entries) {
        QFile file(el);
        QFileInfo info(file);
        if(!info.isDir()) {
            files.append(el);
        }
        file.close();
        file.flush();
    }
    qDebug() << "File inside the json directory : ";
    for(const QString& el : files) {
        qDebug() << el;
    }
    /*-------------------------------------------------------------------------*/qDebug() << ""; qDebug() << ""; qDebug() << "";

    //adesso ho tutti i file json e il loro percorso. Iniziamo a creare per ogni file json il relativo oggetto sensore e aggiungiamolo al vector<sensori*> sensoriBox

    /*loading file datas inside the vector sensoriBox*/
    for(const QString& el : files) {
        QString json_file_path = json_dir + "/" + el;
        QFile file(json_file_path);
        qDebug() << "working with :     " << json_file_path;
        QString file_content;
        if(file.open(QIODevice::ReadOnly)) {
            file_content = file.readAll();
            file.close();
            file.flush();
        }
        QJsonParseError error;
        QJsonDocument doc = QJsonDocument::fromJson(file_content.toUtf8(), &error);
        if(error.error!=QJsonParseError::NoError){
            qWarning() << "File not Parsed " << error.errorString();
            continue;
        }
        QJsonObject sensore = doc.object();
        QString nome_sensore = sensore["nome_sensore"].toString();
        QString descrizione = sensore["descrizione"].toString();
        QString tipo_sensore = sensore["tipo"].toString();
        QJsonArray dati = sensore["dati"].toArray();

        qDebug() << nome_sensore << " " << tipo_sensore << " " << descrizione;

        if(tipo_sensore=="aria") {
            sensoreAria* sa = new sensoreAria(nome_sensore, descrizione);
            vector<dataPair<int>> vec;
            for(auto it=dati.begin(); it!=dati.end(); it++) {
                QJsonObject obj = it->toObject();
                int valore = obj["valore"].toInt();
                int giorno = obj["giorno"].toInt();
                int mese = obj["mese"].toInt();
                int anno = obj["anno"].toInt();
                dataPair<int> dp(valore,giorno,mese,anno);
                vec.push_back(dp);
            }
            sa->setDati(vec);
            sensoriBox.push_back(sa);
            qDebug() << "Finished loading sensoreAria";
        }
        if(tipo_sensore=="temperatura") {
            sensoreTemperatura* st = new sensoreTemperatura(nome_sensore, descrizione);
            vector<dataPair<double>> vec;
            for(auto it=dati.begin(); it!=dati.end(); it++) {
                QJsonObject obj = it->toObject();
                double valore = obj["valore"].toInt();
                int giorno = obj["giorno"].toInt();
                int mese = obj["mese"].toInt();
                int anno = obj["anno"].toInt();
                dataPair<double> dp(valore,giorno,mese,anno);
                vec.push_back(dp);
            }
            st->setDati(vec);
            sensoriBox.push_back(st);
            qDebug() << "Finished loading sensoreTemperatura";


        }
        if(tipo_sensore=="umidita") {
            sensoreUmidita* su = new sensoreUmidita(nome_sensore, descrizione);
            vector<dataPair<int>> vec;
            for(auto it=dati.begin(); it!=dati.end(); it++) {
                QJsonObject obj = it->toObject();
                int valore = obj["valore"].toInt();
                int giorno = obj["giorno"].toInt();
                int mese = obj["mese"].toInt();
                int anno = obj["anno"].toInt();
                dataPair<int> dp(valore,giorno,mese,anno);
                vec.push_back(dp);
            }
            su->setDati(vec);
            sensoriBox.push_back(su);
            qDebug() << "Finished loading sensoreUmidita";
        }

    }

    /*-------------------------------------------------------------------------*/qDebug() << ""; qDebug() << ""; qDebug() << "";


    for(auto it = sensoriBox.begin(); it!=sensoriBox.end(); it++) {
        sensore* s = *it;
        QString nome = s->getNomeSensore();

        QListWidgetItem* item;

        if(typeid(*s)== typeid(sensoreAria)) {
            item = new QListWidgetItem(QIcon(":/icone_GUI/qualita_aria.png"), nome);
            ui->listWidget->addItem(item);
        }
        if(typeid(*s) == typeid(sensoreTemperatura)) {
            item = new QListWidgetItem(QIcon(":/icone_GUI/temperatura.png"), nome);
            ui->listWidget->addItem(item);
        }
        if(typeid(*s) == typeid(sensoreUmidita)) {
            item = new QListWidgetItem(QIcon(":/icone_GUI/umidita.png"), nome);
            ui->listWidget->addItem(item);
        }

    }
    //---------------------------------------------FINE CODICE SETUP LISTA-----------------------------------------------------------





}

void MainWindow::on_pushButton_Show_Chart_clicked()
{

    //prendo il sensore selezionato
    QString sensore_selezionato = ui->label_Sensore_selezionato_value->text();
    if(sensore_selezionato=="") {
        qWarning() << "Nessun sensore selezionato";
        QMessageBox::information(this,"Error", "Seleziona un sensore");
        return;
    }
    qDebug() << "Sensore selezionato" << sensore_selezionato;


    /*--------------------------------------ADDING VALUES TO THE LABELS--------------------------------*/

    for(auto it=sensoriBox.begin(); it!=sensoriBox.end(); it++) {
        sensore* s = *it;
        if(s->getNomeSensore()!=sensore_selezionato) {
            qDebug() << "not this one : " + s->getNomeSensore();
            continue;
        }

        //setto il minimo, il massimo e la media
        ui->label_Max_Value->setText(QString::number(s->getMax()));
        ui->label_Min_Value->setText(QString::number(s->getMin()));
        ui->label_Avg_Value->setText(QString::number(s->getAvg()));
        ui->label_Descrizione_Value->setText(s->descrizione);


        if(dynamic_cast<sensoreAria*>(s)) {
            QString tipo = dynamic_cast<sensoreAria*>(s)->getNomeTipoSensore();
            QString nome_sensore = s->getNomeSensore();
            QString n_valori = QString::number(dynamic_cast<sensoreAria*>(s)->getDati().size());
            QString descrizione = dynamic_cast<sensoreAria*>(s)->descrizione;
            ui->label_tipo_value->setText(tipo);
            ui->label_nome_value->setText(nome_sensore);
            ui->label_n_valori->setText(n_valori);
            ui->label_Descrizione_Value->setText(descrizione);
        }
        if(dynamic_cast<sensoreTemperatura*>(s)) {
            QString tipo = dynamic_cast<sensoreTemperatura*>(s)->getNomeTipoSensore();
            QString nome_sensore = s->getNomeSensore();
            QString n_valori = QString::number(dynamic_cast<sensoreTemperatura*>(s)->getDati().size());
            QString descrizione = dynamic_cast<sensoreTemperatura*>(s)->descrizione;
            ui->label_tipo_value->setText(tipo);
            ui->label_nome_value->setText(nome_sensore);
            ui->label_n_valori->setText(n_valori);
            ui->label_Descrizione_Value->setText(descrizione);
        }
        if(dynamic_cast<sensoreUmidita*>(s)) {
            QString tipo = dynamic_cast<sensoreUmidita*>(s)->getNomeTipoSensore();
            QString nome_sensore = s->getNomeSensore();
            QString n_valori = QString::number(dynamic_cast<sensoreUmidita*>(s)->getDati().size());
            QString descrizione = dynamic_cast<sensoreUmidita*>(s)->descrizione;
            ui->label_tipo_value->setText(tipo);
            ui->label_nome_value->setText(nome_sensore);
            ui->label_n_valori->setText(n_valori);
            ui->label_Descrizione_Value->setText(descrizione);
        }
    /*
    variabili ottenute fino ad ora per il sensore selezionato:
    tipo
    nome_sensore
    n_valori
    descrizione
    */


    }
    /*--------------------------------------------------------------------------------------------------*/

    /*------------------------------------CREAZIONE DEL GRAFICO-----------------------------------------*/
    for(auto it=sensoriBox.begin(); it!=sensoriBox.end(); it++) {
        sensore* s=*it;
        if(s->getNomeSensore()!=sensore_selezionato){
            qDebug() << "not this one : " << s->getNomeSensore();
            continue;
        }
        qDebug() << "creating graph for " + s->getNomeSensore();
        //----------------------------------------------------------------------------------------caso sensore aria
        if(dynamic_cast<sensoreAria*>(s)) {
            //ottengo il vettore all'interno del sensore contenente tutti i dati
            vector<dataPair<int>> dati = dynamic_cast<sensoreAria*>(s)->getDati();

            //devo ottenere la prima e l'ultima data del vettore dati;
            QDateTime past = QDateTime(QDate(dati.begin()->getAnno(),dati.begin()->getMese(), dati.begin()->getGiorno()), QTime());
            QDateTime now = QDateTime(QDate(dati.end()->getAnno(),dati.end()->getMese(), dati.end()->getGiorno()+1), QTime());



            QValueAxis* axisY = new QValueAxis();
            QDateTimeAxis* axisX = new QDateTimeAxis();
            QChart* chart = new QChart();
            QLineSeries* series = new QLineSeries();
            /*Y*/           //values
            axisY->setLabelFormat("%.2f");
            axisY->setTitleText("Values");
            axisY->setMax(250);
            axisY->setMin(0);
            /*X*/           //datas
            axisX->setTickCount(5);
            axisX->setMin(past);
            axisX->setMax(now);
            axisX->setFormat("dd-MM-yyyy");


            qDebug() << "Attaching datas to the graph";
            for(auto it=dati.begin(); it!=dati.end(); it++) {
                qDebug() << QString::number(it->getValore()) + " - " + QString::number(it->getGiorno()) + "/" + QString::number(it->getMese()) + "/" + QString::number(it->getAnno());
                int value = it->getValore();
                QDateTime* data = new QDateTime(QDate(it->getAnno(), it->getMese(), it->getGiorno()), QTime());
                series->append(data->toMSecsSinceEpoch(), value);
            }
            chart->legend()->hide();
            chart->setTitle(s->getNomeSensore());
            chart->addAxis(axisX, Qt::AlignBottom);
            chart->addAxis(axisY, Qt::AlignLeft);
            chart->addSeries(series);
            series->attachAxis(axisX);
            series->attachAxis(axisY);

            QChartView *chartView = new QChartView(chart);

            QLayout *layout = ui->frame_chart->layout();
            if (layout) {
                QLayoutItem *child;
                while ((child = layout->takeAt(0)) != nullptr) {
                    delete child->widget();
                    delete child;
                }
            }

            ui->frame_chart->layout()->addWidget(chartView);



        }
        //-------------------------------------------------------------------------------------caso sensore temperatura
        if(dynamic_cast<sensoreTemperatura*>(s)) {
            //ottengo il vettore all'interno del sensore contenente tutti i dati
            vector<dataPair<double>> dati = dynamic_cast<sensoreTemperatura*>(s)->getDati();

            //devo ottenere la prima e l'ultima data del vettore dati;
            QDateTime past = QDateTime(QDate(dati.begin()->getAnno(),dati.begin()->getMese(), dati.begin()->getGiorno()), QTime());
            QDateTime now = QDateTime(QDate(dati.end()->getAnno(),dati.end()->getMese(), dati.end()->getGiorno()+1), QTime());


            QValueAxis* axisY = new QValueAxis();
            QDateTimeAxis* axisX = new QDateTimeAxis();
            QChart* chart = new QChart();
            QLineSeries* series = new QLineSeries();
            /*Y*/           //values
            axisY->setLabelFormat("%.2f");
            axisY->setTitleText("Values");
            axisY->setMax(60);
            axisY->setMin(-10);
            /*X*/           //datas
            axisX->setTickCount(5);
            axisX->setMin(past);
            axisX->setMax(now);
            axisX->setFormat("dd-MM-yyyy");


            qDebug() << "Attaching datas to the graph";
            for(auto it=dati.begin(); it!=dati.end(); it++) {
                qDebug() << QString::number(it->getValore()) + " - " + QString::number(it->getGiorno()) + "/" + QString::number(it->getMese()) + "/" + QString::number(it->getAnno());
                int value = it->getValore();
                QDateTime* data = new QDateTime(QDate(it->getAnno(), it->getMese(), it->getGiorno()), QTime());
                series->append(data->toMSecsSinceEpoch(), value);
            }
            chart->legend()->hide();
            chart->setTitle(s->getNomeSensore());
            chart->addAxis(axisX, Qt::AlignBottom);
            chart->addAxis(axisY, Qt::AlignLeft);
            chart->addSeries(series);
            series->attachAxis(axisX);
            series->attachAxis(axisY);

            QChartView *chartView = new QChartView(chart);

            QLayout *layout = ui->frame_chart->layout();
            if (layout) {
                QLayoutItem *child;
                while ((child = layout->takeAt(0)) != nullptr) {
                    delete child->widget();
                    delete child;
                }
            }

            ui->frame_chart->layout()->addWidget(chartView);
        }
        //------------------------------------------------------------------------------------caso sensore Umidita
        if(dynamic_cast<sensoreUmidita*>(s)) {
            //ottengo il vettore all'interno del sensore contenente tutti i dati
            vector<dataPair<int>> dati = dynamic_cast<sensoreUmidita*>(s)->getDati();

            //devo ottenere la prima e l'ultima data del vettore dati;
            QDateTime past = QDateTime(QDate(dati.begin()->getAnno(),dati.begin()->getMese(), dati.begin()->getGiorno()), QTime());
            QDateTime now = QDateTime(QDate(dati.end()->getAnno(),dati.end()->getMese(), dati.end()->getGiorno()+1), QTime());


            QValueAxis* axisY = new QValueAxis();
            QDateTimeAxis* axisX = new QDateTimeAxis();
            QChart* chart = new QChart();
            QLineSeries* series = new QLineSeries();
            /*Y*/           //values
            axisY->setLabelFormat("%.2f");
            axisY->setTitleText("Values");
            axisY->setMax(100);
            axisY->setMin(0);
            /*X*/           //datas
            axisX->setTickCount(5);
            axisX->setMin(past);
            axisX->setMax(now);
            axisX->setFormat("dd-MM-yyyy");


            qDebug() << "Attaching datas to the graph";
            for(auto it=dati.begin(); it!=dati.end(); it++) {
                qDebug() << QString::number(it->getValore()) + " - " + QString::number(it->getGiorno()) + "/" + QString::number(it->getMese()) + "/" + QString::number(it->getAnno());
                int value = it->getValore();
                QDateTime* data = new QDateTime(QDate(it->getAnno(), it->getMese(), it->getGiorno()), QTime());
                series->append(data->toMSecsSinceEpoch(), value);
            }
            chart->legend()->hide();
            chart->setTitle(s->getNomeSensore());
            chart->addAxis(axisX, Qt::AlignBottom);
            chart->addAxis(axisY, Qt::AlignLeft);
            chart->addSeries(series);
            series->attachAxis(axisX);
            series->attachAxis(axisY);

            QChartView *chartView = new QChartView(chart);

            QLayout *layout = ui->frame_chart->layout();
            if (layout) {
                QLayoutItem *child;
                while ((child = layout->takeAt(0)) != nullptr) {
                    delete child->widget();
                    delete child;
                }
            }

            ui->frame_chart->layout()->addWidget(chartView);
        }
    }



}

void MainWindow::on_pushButton_Delete_clicked()
{
    QString sensore_selezionato = ui->label_Sensore_selezionato_value->text();


    //passo uno, elimino il sensore dal vettore sensoriBox contenente tutti gli altri sensori
    for(auto it = sensoriBox.begin(); it != sensoriBox.end(); ) {
        sensore* s = *it;
        if(sensore_selezionato == s->getNomeSensore()) {
            //elimino dal vettore
            it = sensoriBox.erase(it);
            delete s; // Elimina l'oggetto sensore
            qDebug() << "Eliminato sensore da sensoriBox";
        } else {
            ++it; // Avanza solo se l'elemento non viene eliminato
        }
    }


    //passo due, elimino dalla lista il sensore selezionato
    for(int i=0; i<ui->listWidget->count();) {
        QListWidgetItem* item = ui->listWidget->item(i);
        if(item->text()==sensore_selezionato) {
            ui->listWidget->removeItemWidget(item);
            delete item;
            qDebug() << "Eliminato sensore dalla lista";
        }
        else {
            ++i;
        }

    }

    //passo 3, e forse anche quello piu fondamentale e difficile. Elimina il file corrispondente nella cartella dei file json
    // Rimozione dei file JSON
    QDir dir(json_dir);
    QStringList entries = dir.entryList(QDir::Files); // Filtra solo i file
    for(const QString& el : entries) {
        QFile file(dir.absoluteFilePath(el)); // Ottieni il percorso assoluto del file
        if(file.open(QIODevice::ReadOnly)) {
            QJsonParseError error;
            QJsonDocument doc = QJsonDocument::fromJson(file.readAll(), &error);
            if(error.error == QJsonParseError::NoError) {
                QJsonObject obj = doc.object();
                QString nome_sensore = obj["nome_sensore"].toString();
                if(nome_sensore == sensore_selezionato) {
                    file.remove();
                    qDebug() << "Eliminato file JSON corrispondente";
                }
            } else {
                qWarning() << "Parsing del file JSON fallito:" << error.errorString();
            }
            file.close();
        } else {
            qWarning() << "Impossibile aprire il file:" << file.fileName();
        }
    }





}

void MainWindow::on_pushButton_Refresh_clicked()
{
    /*
     l'obiettivo è:
        - svuotare la lista dagli elementi presenti
        - svuotare il vettore sensoriBox da tutti gli elementi presenti nel vettore fino a quel momento
        - ricaricare il vettore sensoriBox a seconda dei file json presenti nella cartella
        - ricaricare la lista con i nuovo elementi
    */

    // 1. SVUOTARE LA LISTA
    ui->listWidget->clear();
    qDebug() << "lista svuotata";

    // 2. SVUOTARE SENSORI BOX
    sensoriBox.clear();
    qDebug() << "SensoriBox svuotato. Elementi residui: " + QString::number(sensoriBox.size());

    // 3. RICARICA SENSORIBOX CON I FILE PRESENTI NELLA CARTELLA JSON

    QDir dir(json_dir);
    QStringList files = dir.entryList(QDir::Filter::Files);
    for(const QString& el : files) {
        qDebug() << "working with " + el;
        QFile file(json_dir +"/"+ el);
        if(file.open(QIODevice::ReadOnly)){
            QJsonParseError error;
            QJsonDocument doc = QJsonDocument::fromJson(file.readAll(), &error);
            if(error.error!=QJsonParseError::NoError){
                qWarning() << "Failed to parse json file " + error.errorString();
                continue;
            }
            QJsonObject sensore = doc.object();
            QString nome_sensore = sensore["nome_sensore"].toString();
            QString descrizione = sensore["descrizione"].toString();
            QString tipo = sensore["tipo"].toString();
            QJsonArray dati = sensore["dati"].toArray();

            qDebug() <<"Tipo del sensore" + tipo;
            if(tipo=="aria" || tipo=="Aria"){
                sensoreAria* sa = new sensoreAria(nome_sensore, descrizione);
                vector<dataPair<int>> vec;
                for(auto it=dati.begin(); it!=dati.end(); it++) {
                    QJsonObject obj = it->toObject();
                    int valore=obj["valore"].toInt();
                    int giorno=obj["giorno"].toInt();
                    int mese=obj["mese"].toInt();
                    int anno=obj["anno"].toInt();
                    dataPair<int> dp(valore,giorno,mese,anno);
                    vec.push_back(dp);
                }
                sa->setDati(vec);
                sensoriBox.push_back(sa);
            };
            if(tipo=="temperatura" || tipo=="Temperatura"){
                sensoreTemperatura* st = new sensoreTemperatura(nome_sensore, descrizione);
                vector<dataPair<double>> vec;
                for(auto it=dati.begin(); it!=dati.end(); it++) {
                    QJsonObject obj = it->toObject();
                    double valore=obj["valore"].toDouble();
                    int giorno=obj["giorno"].toInt();
                    int mese=obj["mese"].toInt();
                    int anno=obj["anno"].toInt();
                    dataPair<double> dp(valore,giorno,mese,anno);
                    vec.push_back(dp);
                }
                st->setDati(vec);
                sensoriBox.push_back(st);
            };
            if(tipo=="umidita" || tipo=="Umidita"){
                sensoreUmidita* su = new sensoreUmidita(nome_sensore, descrizione);
                vector<dataPair<int>> vec;
                for(auto it=dati.begin(); it!=dati.end(); it++) {
                    QJsonObject obj = it->toObject();
                    int valore=obj["valore"].toInt();
                    int giorno=obj["giorno"].toInt();
                    int mese=obj["mese"].toInt();
                    int anno=obj["anno"].toInt();
                    dataPair<int> dp(valore,giorno,mese,anno);
                    vec.push_back(dp);
                }
                su->setDati(vec);
                sensoriBox.push_back(su);
            };

            qDebug() << "Finished workin with " << el;

        }
    }

    // 4. RICARICA LA LISTA CON I NUOVI ELEMENTI
    qDebug() << "Elements inside sensoriBox: " + QString::number(sensoriBox.size());
    qDebug() << "Starting to repopulate the list widget";
    for(auto it = sensoriBox.begin(); it!=sensoriBox.end(); it++) {
        sensore* s = *it;
        QString nome = s->getNomeSensore();

        QListWidgetItem* item;

        if(typeid(*s)== typeid(sensoreAria)) {
            qDebug() << "Adding item Aria";
            item = new QListWidgetItem(QIcon(":/icone_GUI/qualita_aria.png"), nome);
            ui->listWidget->addItem(item);
        }
        if(typeid(*s) == typeid(sensoreTemperatura)) {
            qDebug() << "Adding item Temperatura";
            item = new QListWidgetItem(QIcon(":/icone_GUI/temperatura.png"), nome);
            ui->listWidget->addItem(item);
        }
        if(typeid(*s) == typeid(sensoreUmidita)) {
            qDebug() << "Adding item Umidita";
            item = new QListWidgetItem(QIcon(":/icone_GUI/umidita.png"), nome);
            ui->listWidget->addItem(item);
        }

    }

}


void MainWindow::on_pushButton_Save_clicked()
{
    QString sensore_selezionato = ui->label_Sensore_selezionato_value->text();
    if (sensore_selezionato.isEmpty()) {
        QMessageBox::information(this, "Errore", "Seleziona un sensore.");
        return;
    }

    QDir dir(json_dir);
    QStringList files = dir.entryList(QDir::Filter::Files);
    for (const QString& fileName : files) {
        QString filePath = json_dir + "/" + fileName;
        QFile file(filePath);
        if (file.open(QIODevice::ReadWrite)) {
            QJsonParseError error;
            QJsonDocument doc = QJsonDocument::fromJson(file.readAll(), &error);
            if (error.error == QJsonParseError::NoError) {
                QJsonObject sensore = doc.object();
                QString nome_sensore = sensore["nome_sensore"].toString();
                if (nome_sensore == sensore_selezionato) {
                    file.resize(0); // Svuota completamente il file

                    // Scrivi il nuovo contenuto nel file
                    QString newContent = ui->plainTextEdit->toPlainText();
                    if(newContent=="") {
                        QMessageBox::information(this,"Attenzione", "Nessun testo");
                        return;
                    }
                    QByteArray byteArray = newContent.toUtf8();
                    file.write(byteArray);

                    file.close();
                    QMessageBox::information(this, "Successo", "Contenuto del file aggiornato con successo. \nAggiorna la lista \nclicca su show chart per vedere i cambiamenti");
                    return;
                }
            } else {
                qWarning() << "Errore durante il parsing del file JSON: " << error.errorString();
            }
            file.close();
        }
    }

    QMessageBox::warning(this, "Errore", "Sensore non trovato o errore nell'apertura del file.");
    // Aggiorna la lista dei sensori dopo il salvataggio (se necessario)
    on_pushButton_Refresh_clicked();
}



